/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************
----------------------------------------------------------------------
*/

The "ChibiOS" RTOS-Plugin for the J-Link GDB Server is provided by SEGGER as it is.
The Plugin is provided *without* support from SEGGER.
