/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************
----------------------------------------------------------------------
*/

The "Zephyr" RTOS-Plugin for the J-Link GDB Server is provided by SEGGER as it is.
The plugin is provided *without* support from SEGGER.
